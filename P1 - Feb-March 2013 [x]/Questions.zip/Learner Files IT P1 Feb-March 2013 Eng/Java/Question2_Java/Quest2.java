import java.text.DecimalFormat;

/**
 * Type your exam number here
 *  */
public class Quest2  
{
    private String gName;
    private String dName;
    private String mName;
    private int numD;
    private int numT;
    private double tariff;


    public double getTariff() {
        return tariff;
    }

    public String getDName() {
        return dName;
    }

    public String getGName() {
        return gName;
    }

    public int getNumT() {
        return numT;
    }

    public String getMName() {
        return mName;
    }

    public int getNumD() {
        return numD;
    }

}
