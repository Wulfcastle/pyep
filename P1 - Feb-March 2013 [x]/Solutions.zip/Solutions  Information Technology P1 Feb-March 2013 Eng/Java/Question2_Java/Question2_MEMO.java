// Solution for Question 2

   import java.io.BufferedReader;
   import java.io.InputStreamReader;
   import java.io.FileReader;
   import java.io.FileNotFoundException;

    public class Question2_MEMO {
   
       public static void main(String[] args) throws Exception 
      {
         Quest2_MEMO[] tourArray = new Quest2_MEMO[50];
         int counter = 0;
         BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
        // read from file 
         try {
            BufferedReader bf = new BufferedReader(new FileReader("DataQ2.txt"));
            while (bf.readLine() != null)
            {
               counter++;
            }
            counter = counter/2;
         	
            bf = new BufferedReader(new FileReader("DataQ2.txt"));
            for (int cnt = 0; cnt < counter; cnt++)
            //  while (bf.readLine() != null)
            {
               String line1 = bf.readLine();
               String line2 = bf.readLine();
               String[] temp1 = line1.split("&");
               String[] temp2 = line2.split(" for ");
               String[] temp3 = temp2[1].split(" days#");
               tourArray[cnt] = new Quest2_MEMO(temp1[0], temp1[1], temp2[0], Integer.parseInt(temp3[0]), Integer.parseInt(temp3[1]));
              // counter++;
            }
         } 
             catch (FileNotFoundException e) {
               System.out.println(e);
               System.exit(0);
            } 
             catch (Exception f) {
               System.out.println(f);
            }
         char choice = ' ';
         do {
            System.out.println("   MENU\n");
            System.out.println("Option A");
            System.out.println("");
            System.out.println("Q - QUIT");
            System.out.println("\nYour choice?  ");
         
            choice = kb.readLine().toUpperCase().charAt(0);
            switch (choice) {
               case 'A':
                  System.out.print("Enter the name of the month you want to go on tour(e.g. February): ");
                  String mnth = kb.readLine();
               	  
                  System.out.println("\n\nTours for the month of " + mnth);
                  System.out.println("===============================\n");  
                  System.out.println("Number          Destination\n"); 
               		  
                  for (int cnt = 0; cnt < counter - 1; cnt++) {
                     if (tourArray[cnt].getMName().equalsIgnoreCase(mnth)) {
                        System.out.println((cnt + 1)+ "\t\t"+ tourArray[cnt].getDName());
                     }
                  }
                  System.out.print("\nEnter the number of a tour from the list:");
                  int num = Integer.parseInt(kb.readLine());
                  System.out.println("\n" + tourArray[num - 1].toString());
                  System.out.println("\nEnter any character from: " + tourArray[num - 1].getDName());
               
                  char luckyC = kb.readLine().toUpperCase().charAt(0);
                  char genChar = tourArray[num - 1].findLuckyChar();
                  if (luckyC == genChar) {
                     System.out.println("Congratulations! You have received 25% discount on the daily tariff! \nThe tariff was R " + (tourArray[num - 1].getTariff()) + " per day.  It has been reduced to R " + (tourArray[num - 1].getTariff() * 0.75) + " per day\n\n");
                  } 
                  else {
                     System.out.println("The lucky character was " + genChar + ". \nNo discount. The tariff is still R " + tourArray[num - 1].getTariff() + " per day\n\n");
                  }
                  break;
               case 'Q':
                  System.out.println("Quit");
            }
         } while (choice != 'Q');
      }          
   }
