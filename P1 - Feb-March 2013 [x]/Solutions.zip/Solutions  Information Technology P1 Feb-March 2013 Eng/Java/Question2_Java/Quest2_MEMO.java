import java.text.DecimalFormat;

/**
 *
 * Solution for Question 2
 */
public class Quest2_MEMO {
    private String gName;
    private String dName;
    private String mName;
    private int numD;
    private int numT;
    private double tariff;

    public Quest2_MEMO(String gName, String dName, String mName, int numD, int numT) {
        this.gName = gName;
        this.dName = dName;
        this.mName = mName;
        this.numD = numD;
        this.numT = numT;
        setTariff();  
    }


  private void setTariff() 
    {
    	  String sName = mName.toUpperCase();
        //accept solution that dont use toUppercase()
        if (sName.equals("DECEMBER") || sName.equals("APRIL") || sName.equals("SEPTEMBER")) 
           tariff = 1250;
        else
          if (sName.equals("MAY") || sName.equals("MARCH") || sName.equals("JUNE") || sName.equals("JULY"))  
		      tariff = 900;
          else
            tariff = 1000;       
    }

    private String shortenString()
    {
        String shortname = mName.substring(0,1);
        String vowels = "AEIOU";
        //accept solution using lower case letters as well
        for (int cnt = 1; cnt < mName.length();cnt++)
        {
            char letter = mName.charAt(cnt);
            if(vowels.indexOf(mName.toUpperCase().charAt(cnt))<0)
            {
                shortname =shortname + letter;
            }
        }
		  return  shortname;
    }

    public char findLuckyChar()
    {
        int last = dName.length()-1;
        int first = 1;
        int position = 0;
        boolean repeat = true;
        char charac = ' ';
        do
        {
            position = (int)(Math.random() * (last-first+1) + first);
            charac = dName.charAt(position);            
            if (charac != ' ')
            {
                repeat = false;
                charac = dName.charAt(position);
            }            
        }while (repeat == true);
        return charac;
    }

    public String toString()
    {
        DecimalFormat df = new DecimalFormat("R 0.00");
        return "Month: " + shortenString() + "\nDestination: " + dName + " with " +  gName + " as the tour guide\nPrice: " + df.format(getTariff())+ " per day for a period of " + numD + " days\n" + numT+ " tourists are taking this tour.\n";
    }
  
    public double getTariff() {
        return tariff;
    }

    public String getDName() {
        return dName;
    }

    public void setDName(String dName) {
        this.dName = dName;
    }

    public String getGName() {
        return gName;
    }

    public void setGName(String gName) {
        this.gName = gName;
    }

    public int getNumT() {
        return numT;
    }

    public void setNumT(int numT) {
        this.numT = numT;
    }

    public String getMName() {
        return mName;
    }

    public int getNumD() {
        return numD;
    }

    public void setNumD(int numD) {
        this.numD = numD;
    }

}
