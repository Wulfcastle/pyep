import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.sql.*;
import java.util.Scanner;

public class TestQuestion1_MEMO
{
	public static void main (String[] args) throws SQLException,IOException
	{
	
		BufferedReader inKb = new BufferedReader (new InputStreamReader (System.in));
		
		Tourism DB = new Tourism();
		System.out.println();
		
		char choice = ' '; 
		do
		{         
            System.out.println("\n\n      MENU");
            System.out.println();
            System.out.println("    Option A");
            System.out.println("    Option B");
            System.out.println("    Option C");
            System.out.println("    Option D");
            System.out.println("    Option E");
            System.out.println("    Option F");
			   System.out.println("    Option G");
            System.out.println();
            System.out.println("    Q - QUIT");
            System.out.println(" ");
            System.out.print("    Your choice? ");
            choice = inKb.readLine().toUpperCase().charAt(0);
            System.out.println(" ");
            String sql = "";
			switch(choice)
			{
				case 'A':	// Question 1.1
				{
					sql = "SELECT * FROM tblTours ORDER BY Destination, StartDate Desc";  
					
					DB.query(sql);
					break;
				}
		//=============================================================================
           	case 'B':	// Question 1.2
				{		
					sql = "SELECT  TourID,  Firstname, Surname FROM tblTourists WHERE  Firstname LIKE 'C%'AND Surname LIKE 'C%' AND Gender = 'F'";
					DB.query(sql);
					break;
				}
		//=============================================================================
				case 'C': 	// Question 1.3
				{
					System.out.println("Option C\nCountry of origin (for example Spain)? ");
					String sX = inKb.readLine();
					sql = "SELECT  TourID, Surname FROM tblTourists WHERE Deposit AND Country LIKE '" + sX + "%'";  
					
					DB.query(sql);
					break;
				}               
		//=============================================================================
				case 'D':	// Question 1.4
				{
					sql = "SELECT Surname, StartDate, EndDate, (Enddate-StartDate)+1 AS NumberOfDays FROM tblTours WHERE (Startdate >= #2012/06/12#) AND (StartDate <= #2012/10/31#) AND (endDate-StartDate + 1 > 5)";  
					
					DB.query(sql);
					break;
				}
		//=============================================================================
  				case 'E':	// Question 1.5
				{	
					sql = "DELETE FROM tblTours WHERE YEAR(EndDate) = 2011";
					DB.query(sql);
					break;
				}
		//=============================================================================
				case 'F':	// Question 1.6
				{
					sql = "SELECT Country, Format(SUM(AmountPaid),'Currency') AS IncomePerCountry FROM tblTourists GROUP BY Country";  					
					DB.query(sql);
					break;
				}
		//=============================================================================
 				case 'G':	// Question 1.7				
				{
				   sql = "SELECT Destination, StartDate, Seats,Count(tblTourists.Surname)AS [SeatsBooked]  FROM tblTours, tblTourists WHERE tblTourists.TourID = tblTours.TourID GROUP BY Destination, StartDate, Seats HAVING Count(tblTourists.Surname) < tblTours.Seats";  
			 	   DB.query(sql);
					break;
				} 			
		
			}        
		}while (choice != 'Q');  
		
		DB.disconnect();
		System.out.println("Done");  
	}
}