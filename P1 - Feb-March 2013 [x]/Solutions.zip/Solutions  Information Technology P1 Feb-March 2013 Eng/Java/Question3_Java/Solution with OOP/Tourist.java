public class Tourist
{
  private String name;
  private String country;
  private String destination;
  private double money;


  public Tourist(String touristStr)
  {
    int atpos = touristStr.indexOf("@");
     int hashpos = touristStr.indexOf("#");
    name = touristStr.substring(0, atpos);
	 	 
	 country = touristStr.substring(atpos + 1,hashpos);
    String []	temp = touristStr.split("#");
 
    destination = temp[1];
	 money = Double.parseDouble(temp[2]);
 
}  

 public void setDestination(String dest)
 {
   destination = dest;
 }
 
  
//   
//   temp = arrData[cnt].split("@");
//                            System.out.println(temp[0]);	
// 									
// int endpos = arrData[cnt].indexOf("#");
//                   
//                      String destcode = arrData[cnt].substring(endpos + 1,endpos + 4);
																
    

 
 
 public String getName()
 {
   return name;
	}
	
public String getCountry()
 {
   return country;
	}
	
public String getDestination()
 {
   return destination;
	}
	
	public double getMoney()
 {
   return money;
	}
	
 }
