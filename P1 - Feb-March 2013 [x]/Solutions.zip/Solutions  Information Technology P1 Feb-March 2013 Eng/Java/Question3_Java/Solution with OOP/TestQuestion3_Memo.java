import java.io.IOException;

public class TestQuestion3_Memo
{
   public static void main(String[] args) throws Exception {
         Question3_MEMO Q3 = new Question3_MEMO();
			Q3.runMenu();
		}
}
			
     
