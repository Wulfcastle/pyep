
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Solution Question 3 
 */
    public class Question3_MEMO {
   
String[] arrData = {"Rachel Delarosa@Canada#SH#11861","Corradino Grande@Spain#RO#5788", 
"Lucas Herder@Germany#KR#7709", "Estotz Lizarazu@France#GA#12349", 
"Chynna Taylor@England#GA#8551", "Renata Di@Spain#RO#4906", 
"Ugs Boulot-Tolle@France#CA#7300", "Lena Bucholtz@Germany#GA#10344", 
"Maria Heimpel@Germany#SH#9438", "Julian Amstadter@Germany#RO#8840", 
"Sofie Mosbauer@Germany#GA#5894", "Fiona Green@England#CA#9094", 
"Sara Escobedo@Canada#KR#4381", "Nataly Mahan@Canada#RO#12642", 
"Wyatt Parham@Canada#SH#4799", "Noah Donovan@Canada#SH#3888", 
"Joseph Scott@England#SH#7928", "Emily Smith@England#KR#3110", 
"Adriana Mancuso@Spain#RO#3724", "Cassandra Wilder@Canada#KR#12583", 
"Tomasino Camporese@Spain#KR#6777", "Stacy Anderson@England#RO#3686", 
"Guiraud Bluteau@France#RO#11592", "Damian Friedman@Canada#RO#9012", 
"Anne Loef@Germany#KR#13035", "Terence Brown@England#SH#8180", 
"Lion Ghislieri@Spain#RO#14343", "Giraudetz Girardin@France#CA#11644", 
"Guglielmo Capriati@Spain#SH#5408", "David Geiberger@Germany#RO#9854", 
"Irisa Cooper@England#KR#11456", "Hayden Mcdonough@Canada#KR#7840", 
"Jonas Hipp@Germany#RO#3137", "Emily Kohler@Germany#GA#6509", 
"Emily Thul@Germany#RO#8551", "Gino Lazzaretti@Spain#CA#2329", 
"Alex Hofstater@Germany#GA#6751", "Peers Scott@England#RO#9470", 
"Liliana Horne@Canada#RO#14689", "Leon Kleinpaul@Germany#RO#15194"};
   			  
      String []arrDestinations = {"Cape Winelands","Garden Route", "Kruger National Park", 
			"Robben Island (English tour)","Robben Island (Other tour)", "Shakaland"};
   	
      BufferedReader kb;
   public void convertEuros()
	{
	 double value = 0;
                  for (int cnt = 0; cnt < arrData.length; cnt++) 
                  {
                     if (arrData[cnt].indexOf("France")>=0 ||arrData[cnt].indexOf("Spain")>=0||arrData[cnt].indexOf("Germany")>=0) 
                     { 	
                        String[] temp = arrData[cnt].split("#");
                        value = value + Double.parseDouble(temp[2]);
                     }
                  }   
                 System.out.printf("%s%-8.0f\n","Total amount in euro: ", value);
                  double rand = value*10.75;
                  System.out.printf("%sR%10.2f\n\n","Total amount in South African rand: ", rand); 
				       		
	}
	 public void divideGroup()
	 {
	  System.out.println("List of English-speaking tourists to Robben Island");
     System.out.println("==================================================");
     for (int cnt = 0; cnt < arrData.length; cnt++) 
     {
      if (arrData[cnt].indexOf("#RO#") >= 0) 
      {											
      if (arrData[cnt].indexOf("England") >= 0 || arrData[cnt].indexOf("Canada") >= 0)
       {
          String[] temp = arrData[cnt].split("@");
          System.out.println(temp[0]);							
          arrData[cnt] = arrData[cnt].replace("#RO#","#ROEnglish#");																			
       }
       else
       {
         arrData[cnt] = arrData[cnt].replace("#RO#","#ROOther#");
       }
     }
    }		
    System.out.println("\n\n"); 
   }
   public void determinePopularity()
   {
    int[] arrCount = new int[6];
    System.out.println("Star rating of tours");
    System.out.println("===============================================================");
    System.out.println("Destination                        Rating    Number of tourists");
    System.out.println("===============================================================");
	 for (int c = 0; c < 6; c++)
	 {
		arrCount[c]=0;
	 }
	 
    for (int c = 0; c < arrData.length; c++) 
    {
      int endpos = arrData[c].indexOf("#");
      String destcode = arrData[c].substring(endpos + 1,endpos + 4);
		switch (destcode.toUpperCase().charAt(0))
		{
				case 'C' : arrCount[0]++; break;
				case 'K' : arrCount[2]++; break;
				case 'G' : arrCount[1]++; break;
				case 'R' : if (destcode.toUpperCase().charAt(2) == 'E')
									arrCount[3]++;
							  else arrCount[4]++;break;
				case 'S' : arrCount[5]++;break;				
				}           
    }
    // output
    for (int index = 0; index < 6; index++)
    {
     	String starString = "";
	   int numStars = arrCount[index]/3;
      for (int stars = 0; stars < numStars; stars++)
      {
        starString = starString + "*";
      }
      String outString = String.format("%-35s%-10s(%d)",arrDestinations[index],starString,arrCount[index]);
      System.out.println(outString);                        
    }
	System.out.println("\n\n");
 }
 public Question3_MEMO() throws Exception {
 kb = new BufferedReader(new InputStreamReader(System.in));
 char choice =' ';
 do {
      System.out.println("MENU");
      System.out.println();
      System.out.println("   Option A");
      System.out.println("   Option B");
      System.out.println("   Option C");
      System.out.println();
      System.out.println("Q - QUIT");
      System.out.println();
      System.out.println("Your choice?");
      choice = kb.readLine().toUpperCase().charAt(0);
      switch (choice) {
      case 'A': convertEuros();     						
                break;
      case 'B':divideGroup();
                break;
      case 'C':determinePopularity();
                break;
      case 'Q':
               System.out.println("QUIT");
     }
     } while (choice != 'Q');
    }
   
    public static void main(String[] args) throws Exception {
         new Question3_MEMO();
    }
	
   }
