 import java.io.IOException;  

 
 public class TestQuestion3Memo
 {
 
  public static void main(String[] args) throws IOException
      {
         Question3_Memo test = new Question3_Memo();
			test.displayMenu();
      }
}